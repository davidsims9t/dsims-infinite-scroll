# Contributing to David's Infinite Scroll

Well if this was an actually maintained product, I would put some instructions here on contributing, but since it isn't I'm not. 
